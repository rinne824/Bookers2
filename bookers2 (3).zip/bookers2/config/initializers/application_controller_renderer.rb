# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '97141438b9b8f0e83819d93a665b48f61753bde47b93da8792ec61c5dbe5e7449b40075536080807d583a627491c699c4aa9a8836e8de774f6d3084f0cc4e598'
